from django.apps import AppConfig


class AppfourConfig(AppConfig):
    name = 'appfour'
