from django.contrib import admin
from appfour.models import UserProfileInfo,TravelDetails
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(TravelDetails)
