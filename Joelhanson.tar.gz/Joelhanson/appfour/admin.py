from django.contrib import admin
from appfour.models import UserProfileInfo,TravelDetails,Places
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(TravelDetails)
admin.site.register(Places)
